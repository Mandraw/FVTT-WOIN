export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "systems/WOIN-System/templates"
    ];
    return loadTemplates(templatePaths);
};
